# v0.2.0 — DOI-Linked Manuscript and Supplementary Information

This release adds the DOI-updated main manuscript and supplementary information for the synthetic chemoinformatics benchmark, alongside their LaTeX sources and the SHAP figure used by the manuscript.

## Contents

- Main manuscript PDF and LaTeX source
- Supplementary Information PDF and LaTeX source
- SHAP figure referenced by the main LaTeX source
- The dataset, archived metrics, reproduction script, substrate library, and traceability documentation already present in the repository

## Scope and limitations

All reactions and target labels are synthetic. No experimental validation is claimed. The archived 20-seed metrics match the manuscript's summary statistics to three decimal places, but an independent clean rerun of the complete cross-validation suite has not yet completed successfully. The TreeSHAP result is illustrative for one fitted Seed 42 model, and the Green Prioritization Index is an author-defined heuristic rather than a validated sustainability metric.

## Citation and DOI

Use the Zenodo concept DOI, https://doi.org/10.5281/zenodo.23383768, for the project across versions. Zenodo will assign a new version-specific DOI after this release is archived. The initial preliminary v0.1.0 release has version DOI https://doi.org/10.5281/zenodo.23383769.

## Licensing

The Python source code is licensed under MIT. Dataset files and written documentation are licensed under CC BY 4.0; see LICENSE and LICENSE-DATA.md. Please verify that the Zenodo record reflects the mixed licenses.
